NBTCE509P - Practical Programs

8086 (DOSBox, TASM)         8085 (sim8085.com)
ADD8.ASM    - Program 1     EXCHANGE_8085.txt - Program 2
STRING.ASM  - Program 3     ADD24_8085.txt    - Program 5
MUL4.ASM    - Program 4
ASCEND.ASM  - Program 6

Run in DOSBox:
  MOUNT C C:\TASM
  C:
  TASM ADD8.ASM
  TLINK ADD8.OBJ
  ADD8.EXE        (or TD ADD8.EXE to step through)
Copy the .ASM files into your C:\TASM folder first.
For 8085, paste the .txt contents into sim8085.com.
