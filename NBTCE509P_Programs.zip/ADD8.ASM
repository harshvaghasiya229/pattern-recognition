; Program 1: Add two 8-bit numbers, result in DH and BH (8086)
DATA SEGMENT
  X DB 05H
  Y DB 06H
DATA ENDS
CODE SEGMENT
ASSUME CS:CODE, DS:DATA
START:
  MOV AX, DATA
  MOV DS, AX
  MOV AL, X
  MOV BL, Y
  ADD AL, BL      ; AL = 0BH
  MOV DH, AL      ; result in DH
  MOV BH, AL      ; or BH (change this line for any register)
  INT 3H
CODE ENDS
END START
