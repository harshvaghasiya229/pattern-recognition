; Program 6: Arrange numbers in ascending order - bubble sort (8086)
; For 6 numbers use: ARR DB 25,7,42,13,9,30  and  N DB 6
; Keep values below 100 (display prints two digits)
DATA SEGMENT
  ARR DB 35, 9, 15, 14
  N   DB 4
  MSG DB "Ascending order: $"
DATA ENDS
CODE SEGMENT
ASSUME CS:CODE, DS:DATA
START:
  MOV AX, DATA
  MOV DS, AX
  MOV CL, N
  DEC CL                 ; passes = N-1
L1: LEA SI, ARR
  MOV CH, CL             ; comparisons in this pass
L2: MOV AL, [SI]
  CMP AL, [SI+1]
  JBE L3                 ; already in order, skip swap
  MOV BL, [SI+1]
  MOV [SI+1], AL
  MOV [SI], BL
L3: INC SI
  DEC CH
  JNZ L2
  DEC CL
  JNZ L1
  LEA DX, MSG
  MOV AH, 09H
  INT 21H
  LEA SI, ARR
  MOV CL, N
L4: MOV AL, [SI]
  MOV AH, 0
  MOV BL, 10
  DIV BL                 ; AL = tens, AH = units
  MOV BH, AH
  ADD AL, 30H            ; to ASCII
  MOV DL, AL
  MOV AH, 02H
  INT 21H
  MOV DL, BH
  ADD DL, 30H
  MOV AH, 02H
  INT 21H
  MOV DL, " "
  MOV AH, 02H
  INT 21H
  INC SI
  DEC CL
  JNZ L4
  MOV AX, 4C00H
  INT 21H
CODE ENDS
END START
