; Program 4: Multiply two 4-bit numbers, result in AX and CX (8086)
DATA SEGMENT
  X DB 0AH       ; 4-bit numbers (0 to 0FH)
  Y DB 05H
DATA ENDS
CODE SEGMENT
ASSUME CS:CODE, DS:DATA
START:
  MOV AX, DATA
  MOV DS, AX
  MOV AL, X
  MOV BL, Y
  MUL BL         ; AX = AL x BL = 0032H (50)
  MOV CX, AX     ; result also in CX
  INT 3H
CODE ENDS
END START
